"""Fixed course baseline: 30,000 symmetric InfoNCE optimizer updates."""
import argparse
import hashlib
import json
import math
import os
import random
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torchvision.datasets import MNIST, SVHN
from torchvision.transforms import ToTensor


class ContrastiveEncoders(nn.Module):
    def __init__(self):
        super().__init__()
        self.mnist = nn.Sequential(nn.Flatten(), nn.Linear(784, 512), nn.ReLU(),
                                   nn.Linear(512, 256), nn.ReLU(), nn.Linear(256, 64))
        blocks = []
        for a, b in zip((3, 32, 64, 128), (32, 64, 128, 256)):
            blocks.extend((nn.Conv2d(a, b, 4, 2, 1), nn.BatchNorm2d(b), nn.ReLU()))
        self.svhn = nn.Sequential(*blocks, nn.Flatten(), nn.Linear(1024, 64))
        self.log_temperature = nn.Parameter(torch.tensor(math.log(0.07)))

    def forward(self, m, s):
        return F.normalize(self.mnist(m), dim=-1), F.normalize(self.svhn(s), dim=-1)


def contrastive_loss(m, s, log_temperature):
    logits = (m @ s.T) / log_temperature.exp()
    labels = torch.arange(len(m), device=m.device)
    return (F.cross_entropy(logits, labels) + F.cross_entropy(logits.T, labels)) / 2


class PairBatches:
    """Shuffled epochs with explicit, checkpointable batch position; drop remainder."""
    def __init__(self, n, seed, batch=256):
        self.n, self.batch = n, batch
        self.rng = np.random.default_rng(seed)
        self.order, self.pos = None, 0

    def next(self):
        if self.order is None or self.pos + self.batch > self.n:
            self.order, self.pos = self.rng.permutation(self.n), 0
        ids = self.order[self.pos:self.pos + self.batch]
        self.pos += self.batch
        return ids

    def state_dict(self):
        return dict(order=self.order, pos=self.pos, rng=self.rng.bit_generator.state)

    def load_state_dict(self, state):
        self.order, self.pos = state['order'], state['pos']
        self.rng.bit_generator.state = state['rng']


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-root', type=Path, default=Path('data'))
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--seed', type=int, default=2026)
    p.add_argument('--data-seed', type=int, default=2026)
    p.add_argument('--steps', type=int, default=30000,
                   help='Use a separate output directory for short smoke tests.')
    p.add_argument('--save-every', type=int, default=500)
    p.add_argument('--resume', action='store_true')
    args = p.parse_args()
    if not torch.cuda.is_available():
        raise SystemExit('CUDA GPU unavailable. Select a GPU runtime in Colab.')
    if not 1 <= args.steps <= 30000 or args.save_every < 1:
        p.error('steps must be 1..30000 and save-every must be positive')
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)
    device = torch.device('cuda')
    idx = args.data_root / 'indices' / f'seed_{args.data_seed}'
    if not (idx / 'manifest.json').exists():
        raise SystemExit(f'Complete data preparation first: {idx}')
    pair_path = idx / 'pairs_train.npy'
    digest = hashlib.sha256(pair_path.read_bytes()).hexdigest()
    manifest = json.loads((idx / 'manifest.json').read_text())
    if digest != manifest['sha256']['pairs_train.npy']:
        raise SystemExit('Training pairs differ from saved manifest')
    pairs = np.load(pair_path, mmap_mode='r')
    mds = MNIST(str(args.data_root / 'raw'), train=True, download=True)
    sds = SVHN(str(args.data_root / 'raw' / 'SVHN'), split='train', download=True)
    # Cache uint8 source images in host RAM; convert only selected batches.
    mx, sx = mds.data, torch.from_numpy(sds.data)
    model = ContrastiveEncoders().to(device)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    stream = PairBatches(len(pairs), args.seed)
    config = dict(seed=args.seed, data_seed=args.data_seed, pair_sha256=digest,
                  batch_size=256, learning_rate=1e-3, dimension=64,
                  objective='symmetric InfoNCE; diagonal positives only', amp=False)
    args.output.mkdir(parents=True, exist_ok=True)
    checkpoint_path = args.output / 'latest.pt'
    start, history = 0, []
    if checkpoint_path.exists():
        if not args.resume:
            raise SystemExit('Checkpoint exists; add --resume or use another output folder')
        # Load only your own trusted checkpoint; it includes Python/NumPy RNG states.
        ck = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
        if ck['config'] != config:
            raise SystemExit('Checkpoint configuration/data mismatch')
        model.load_state_dict(ck['model']); opt.load_state_dict(ck['optimizer'])
        for state in opt.state.values():
            for key, value in state.items():
                if torch.is_tensor(value) and key != 'step': state[key] = value.to(device)
        stream.load_state_dict(ck['sampler'])
        random.setstate(ck['python_rng']); np.random.set_state(ck['numpy_rng'])
        torch.set_rng_state(ck['torch_rng'])
        torch.cuda.set_rng_state_all(ck['cuda_rng'])
        start, history = ck['step'], ck['history']
    elif args.resume:
        print('No checkpoint yet; starting fresh.', flush=True)
    versions = dict(torch=torch.__version__, numpy=np.__version__,
                    gpu=torch.cuda.get_device_name(0))
    (args.output / 'config.json').write_text(json.dumps(config | versions, indent=2))

    def save(step):
        ck = dict(step=step, config=config, model=model.state_dict(),
                  optimizer=opt.state_dict(), sampler=stream.state_dict(), history=history,
                  python_rng=random.getstate(), numpy_rng=np.random.get_state(),
                  torch_rng=torch.get_rng_state(), cuda_rng=torch.cuda.get_rng_state_all())
        temporary = args.output / 'latest.tmp.pt'
        torch.save(ck, temporary)
        temporary.replace(checkpoint_path)
        (args.output / 'loss.json').write_text(json.dumps(history))

    print(f"GPU: {versions['gpu']}; updates {start} -> {args.steps}; "
          f"parameters: {sum(t.numel() for t in model.parameters()):,}", flush=True)
    model.train()
    begin = time.monotonic()
    for step in range(start + 1, args.steps + 1):
        pair = np.array(pairs[stream.next()], copy=True)
        m = mx[pair[:, 0]].unsqueeze(1).to(device, dtype=torch.float32) / 255
        s = sx[pair[:, 1]].to(device, dtype=torch.float32) / 255
        opt.zero_grad(set_to_none=True)
        em, es = model(m, s)
        loss = contrastive_loss(em, es, model.log_temperature)
        if not torch.isfinite(loss):
            raise RuntimeError(f'Non-finite loss at step {step}; resume last saved checkpoint')
        loss.backward()
        opt.step()  # Full precision: each loop iteration is one successful update.
        history.append(dict(step=step, loss=float(loss.detach()),
                            temperature=float(model.log_temperature.exp().detach())))
        if step % 100 == 0 or step == 1:
            elapsed = time.monotonic() - begin
            print(f"step={step} loss={history[-1]['loss']:.4f} "
                  f"temperature={history[-1]['temperature']:.4f} "
                  f"updates/sec={(step-start)/max(elapsed, 1e-6):.2f}", flush=True)
        if step % args.save_every == 0 or step == args.steps:
            save(step)
    # A short smoke run never produces the official final encoder artifact.
    if args.steps == 30000:
        model.eval().requires_grad_(False)
        torch.save(dict(model=model.state_dict(), config=config, step=30000),
                   args.output / 'frozen_encoders.pt')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.plot([h['step'] for h in history], [h['loss'] for h in history], alpha=.5)
    plt.xlabel('Optimizer update'); plt.ylabel('Symmetric InfoNCE loss')
    plt.tight_layout(); plt.savefig(args.output / 'training_loss.png', dpi=150)
    print('Finished. Saved checkpoint, configuration, loss log and plot.', flush=True)


if __name__ == '__main__':
    main()
